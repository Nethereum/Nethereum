This package contains third-party software components governed by the license(s) indicated below:

Component Name: NBitcoin

License Type: "MIT"

[NBitcoin License](https://github.com/MetacoSA/NBitcoin/blob/master/LICENSE)

Component Name: ADRaffy.ENSNormalize

License Type: "MIT"

[ADRaffy.ENSNormalize License](https://github.com/adraffy/ENSNormalize.cs/blob/main/LICENSE)

Component Name: BouncyCastle.Crypto

License Type: "MIT"

[BouncyCastle.Crypto](https://www.bouncycastle.org/licence.html)

Component Name: Microsoft.Extensions.Logging.Abstractions

License Type: "MIT"

[Microsoft.Extensions.Logging.Abstractions](https://github.com/dotnet/runtime/blob/main/LICENSE.TXT)

Component Name: Newtonsoft.Json

License Type: "MIT"

[Newtonsoft.Json](https://github.com/JamesNK/Newtonsoft.Json/blob/master/LICENSE.md)

Component Name: Common.Logging

License Type: "Apache 2.0"

[Common.Logging](https://github.com/net-commons/common-logging/blob/master/license.txt)