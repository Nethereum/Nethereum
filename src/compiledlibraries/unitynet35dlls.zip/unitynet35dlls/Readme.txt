Compiled Nethereum libraries using net351, for compatibility with Unity3d
Json.Net is the AOT version created by https://github.com/SaladLab/Json.Net.Unity3D